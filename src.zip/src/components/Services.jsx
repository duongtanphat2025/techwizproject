const services = [
  require("../img/ac.png"),
  require("../img/ac2.png"),
  require("../img/ac1.PNG"),
  require("../img/icu.png"),
  require("../img/icu1.png"),
  require("../img/icu2.png"),
  require("../img/nomal1.png"),
  require("../img/nomal2.PNG"),
  require("../img/nomal.PNG"),
  require("../img/nonac1.png"),
  require("../img/nonac2.png"),
  require("../img/nonac3.PNG"),
  require("../img/nonicu1.png"),
  require("../img/nonicu2.png"),
  require("../img/nonicu3.png"),
];
export default services;
