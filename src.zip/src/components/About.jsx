import React from 'react';

function About() {
  return (
    <div>
      <h1>About LifeLink</h1>
      <p>LifeLink is dedicated to providing fast and reliable eAmbulance services during critical situations.</p>
    </div>
  );
}

export default About;
